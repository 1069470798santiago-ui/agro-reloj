AGROWEB - PROTOTIPO ACADEMICO
================================

Contenido
- index.html: aplicación web de demostración.

Acceso demostrativo
- Correo: demo@agroweb.local
- Contraseña: Agro2026

IMPORTANTE
Esta versión es un prototipo de interfaz de bajo nivel. Las lecturas de humedad,
temperatura, pH, presión y caudal son demostrativas/simuladas. No existe conexión
con sensores físicos ni base de datos en la nube. Los cultivos añadidos desde el
formulario permanecen solamente durante la sesión del navegador.

Publicación HTTPS con GitHub Pages
1. Inicia sesión en GitHub y crea un repositorio público, por ejemplo: agroweb.
2. Sube el archivo index.html a la raíz del repositorio.
3. En Settings > Pages, selecciona Deploy from a branch.
4. Selecciona la rama main y la carpeta /(root), y guarda.
5. Espera a que GitHub Pages publique el sitio. El enlace tendrá la forma:
   https://TU-USUARIO.github.io/agroweb/
6. Abre el enlace en una ventana privada y prueba el acceso.

Seguridad
Las credenciales están escritas en el código y solo sirven para una demostración.
No uses esta autenticación para datos privados ni para un sistema de producción.
Para usuarios reales se necesita autenticación segura del lado del servidor
(por ejemplo Firebase Authentication) y reglas de acceso a la base de datos.

Pruebas sugeridas
- Iniciar sesión con las credenciales de demostración.
- Navegar por todos los módulos.
- Registrar un cultivo y verificar que aparece en la lista.
- Activar y restablecer la anomalía de agua.
- Permitir GPS y comprobar que el mapa centra la ubicación.
- Tomar capturas de cada prueba y registrar tiempos/observaciones reales.
